```ad-gallery-print
![[CielPhantomhive.jpg]]

![[Grog.jpg]]
```