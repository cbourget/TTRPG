# Plan

## NPCs
- [ ] Eryn: Attirer l'attention sur la déchéance commise à l'encontre d'Osiron.
- [ ] Pirate: Fuir la cité car il est recherché pour ses crimes
- [ ] Jeunot: Prouver à sa famille qu'il est digne et démontrer sa valeur
- [ ] Barde aberrant: Former un groupe de héros qui seront les protagonistes de son récit épique
- [ ] Brute/Marin 1: S'enrichir
- [ ] Brute/Marin 2: S'enrichir
- [ ] Linguiste: Être l'interprète et apprendre la langue des Pthumériens.

## Scénario
### Expédition
- [x] [[Guilde Marchande]]
	- [x] [[Agrippine]]
	- [x]  [[Bran Ilvastar]]
	- [x] [[Hossulim]]
	- [x] [[Horadin Fulgor]]
- [x] [[Syndic Des Marchands]]
	- [x] [[Nilheim]]
	- [x] [[Xendra Mantar]]
	- [x] [[Corbu]]
	- [x] [[Harald]]
- [x] [[Mantar]]
	- [x] [[Crik Mantar]]
	- [x] [[Samora]]
- [ ] [[Ligue Frégate]]
	- [x] [[Randal Carodoc]]
	- [x] [[Roy Larg]]
	- [x] [[Cleyton Kilmer]]
	- [ ] Ouvert 1
	- [ ] Ouvert 2
- [x] [[Estelmer]]
	- [x] [[Vladimir Estelmer]]
- [x] [[Ilvastar]]
	- [x] [[Penny Ilvastar]]
- [x] [[Cragmire]]
	- [x] [[Frya Cragmire]]
	- [x] [[Kretiak Cragmire]]
- [x] [[Lanngolyn]]
	- [x] [[Logan Lanngolyn]]
- [x] [[Tamerlane Foghorn]]
	- [x] [[Alcide Foghorn]]
	- [x] [[Rackham]]
	- [x] [[Meredia]]
- [ ] [[Académie des Noms]]
	- [ ] Membre 1
- [ ] [[Église d'Osiron]]
	- [ ] [[Perrin]]
	- [ ] [[Wilhelm Oberon]]
	- [ ] Ouvert 1
- [ ] [[Christofle]]
	- [ ] [[Christofle]]
	- [ ] Ouvert 1
	- [ ] Ouvert 2
	- [ ] Ouvert 3
	- [ ] Ouvert 4
	- [ ] Ouvert 5
- [ ] Autres
	- [ ] [[Grog]] 
	- [ ] [[Gatsby]]
	- [ ] [[Corgak]]
	- [ ] [[Livia]]
	- [ ] [[Héron]] (ranger / chasseur)
	- [ ] [[Talarissa]] (ranger / chasseuse)
	- [ ] [[Cook]]
	- [ ] [[Dom]]
	- [ ] [[Albert]]
	- [ ] [[Wisgar]]


### TODO
- [ ] Finir les NPCs
- [ ] Carte de Nostaria
- [ ] Stats des Mutagen
- [ ] Écrire certaines répliques et flow du scénario
- [ ] Façon d'obtenir des indices (tokens)
- [ ] Encounters du scénario
- [ ] Background Pete
- [ ] Imprimer les standees et les découper