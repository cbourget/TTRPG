
---
cssclass: 'npc'
tags: NPC Cragmire
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Kretiak Cragmire
```ad-desc
<span class="image">![[Kretiak Cragmire.jpg]][[Kretiak Cragmire.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
<span class="tab">[[Cragmire#Objectifs]]</span>
<span class="embed-section tab">![[Cragmire#Objectifs]]</span>

## Détails

## Relations
<span class="tab">[[Cragmire#Relations]]</span>
<span class="embed-section tab">![[Cragmire#Relations]]</span>

## Secrets

## Statistiques