
---
cssclass: 'npc'
tags: NPC Non-Affilié Abadar
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Grog
```ad-desc

<span class="image">![[Grog.jpg]][[Grog.jpg|Voir]]</span>

<span class="npc-tags">#Nain #Homme</span>

<span>Discple d'Abadar qui suit une étoile qu'il croit être un signe de son dieu.</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>

```

## Objectifs
- [ ] Fonder uen civilisation là où l'étoile le mènera.

## Détails

## Relations

## Secrets

## Statistiques