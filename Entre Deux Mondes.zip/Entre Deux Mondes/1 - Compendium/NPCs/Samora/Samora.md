
---

cssclass: 'npc'
tags: NPC

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Samora

```ad-desc

<span class="image">![[Samora.jpg]][[Samora.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Femme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
- [ ] Être l'interprète et apprendre la langue des Pthumériens

## Détails

## Relations

## Secrets

## Statistiques