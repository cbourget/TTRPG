
---
cssclass: 'npc'
tags: NPC Non-Affilié
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Ronzu
```ad-desc

<span class="image">![[Ronzu.jpg]][[Ronzu.jpg|Voir]]</span>

<span class="npc-tags">#Gnome #Femme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
- [ ] Cartographier le nouveau contient.

## Détails

## Relations

## Secrets

## Statistiques