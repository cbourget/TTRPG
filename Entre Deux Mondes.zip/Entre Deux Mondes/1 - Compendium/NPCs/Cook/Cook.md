
---

cssclass: 'npc'
tags: NPC

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Cook

```ad-desc

<span class="image">![[Cook.jpg]][[Cook.jpg|Voir]]</span>

<span class="npc-tags">#Orc #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails

## Relations

## Secrets

## Statistiques