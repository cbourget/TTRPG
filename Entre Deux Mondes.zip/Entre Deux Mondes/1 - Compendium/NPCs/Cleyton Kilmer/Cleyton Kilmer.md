
---
cssclass: 'npc'
tags: NPC Kilmer
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Cleyton Kilmer
```ad-desc
<span class="image">![[Cleyton Kilmer.jpg]][[Cleyton Kilmer.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Le découvreur du nouveau continent récemment revenu à [[Brevoy]] pour faire part de sa découverte. Il est très nerveux car il a l'impression d'être suivi depuis son retour. </span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails

## Relations

## Secrets

## Statistiques