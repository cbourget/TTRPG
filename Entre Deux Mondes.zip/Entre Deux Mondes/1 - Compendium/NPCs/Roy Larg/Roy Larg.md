
---
cssclass: 'npc'
tags: NPC Larg Ligue-Frégate
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Roy Larg
```ad-desc

<span class="image">![[Roy Larg.jpg]][[Roy Larg.jpg|Voir]]</span>

<span class="npc-tags">#Humain #FHomme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
<span class="tab">[[Ligue Frégate#Objectifs]]</span>
<span class="embed-section tab">![[Ligue Frégate#Objectifs]]</span>

## Détails

## Relations

## Secrets

## Statistiques