
---

cssclass: 'npc'
tags: NPC Mantar

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Seymor Mantar

```ad-desc

<span class="image">![[Seymor Mantar.jpg]][[Seymor Mantar.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails

## Relations

## Secrets

## Statistiques