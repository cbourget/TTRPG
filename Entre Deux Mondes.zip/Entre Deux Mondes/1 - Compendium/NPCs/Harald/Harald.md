
---

cssclass: 'npc'
tags: NPC Syndic-Des-Marchands 

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Harald

```ad-desc

<span class="image">![[Harald.jpg]][[Harald.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails

## Relations

## Secrets

## Statistiques