
---
cssclass: 'npc'
tags: NPC Syndic-Des-Marchands
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Corbu
```ad-desc
<span class="image">![[Corbu.jpg]][[Corbu.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Un haut placé du [[Syndic Des Marchands]].</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
<span class="tab">[[Syndic Des Marchands#Objectifs]]</span>
<span class="embed-section tab">![[Syndic Des Marchands#Objectifs]]</span>

## Détails

## Relations
| -                        | Relation                                                                                               |
| ------------------------ | ------------------------------------------------------------------------------------------------------ |
| [[Syndic Des Marchands]] | Membre] |
| [[Capes Jaunes]]         | Les a engagés et les traite comme tels.                                                                                                 |
| [[Guilde Marchande]] | Déteste la guilde car il considère qu'elle ne représente pas les intérêts des marchands mais plutôt ceux de [[Brevoy]]

## Secrets

## Statistiques