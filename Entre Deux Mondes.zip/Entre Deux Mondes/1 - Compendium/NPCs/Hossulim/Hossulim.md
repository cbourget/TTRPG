
---
cssclass: 'npc'
tags: NPC Guilde-Marchande
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Hossulim
```ad-desc

<span class="image">![[Hossulim.jpg]][[Hossulim.jpg|Voir]]</span>

<span class="npc-tags">#Nain #Homme</span>

<span>Délégué au commerce extérieur de la [[Guilde Marchande]]</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```


## Objectifs
<span class="tab">[[Guilde Marchande#Objectifs]]</span>
<span class="embed-section tab">![[Guilde Marchande#Objectifs]]</span>

## Détails

## Relations
| -                        | Relation                            |
| ------------------------ | ----------------------------------- |
| [[Guilde Marchande]]     | Membre                              |
| [[Capes Jaunes]]         | Les a engagés et les traite bien.   |
| [[Syndic Des Marchands]] | Déteste le [[Syndic Des Marchands]] |


## Secrets

## Statistiques