
---

cssclass: 'npc'
tags: NPC Non-Affilié

---
<span class="npc-tags">#Humain #Homme</span>

# Aruspice
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [Relations](#Relations) [Statistiques](#Statistiques) [Secrets](#Secrets)</span>

```ad-desc

<span class="image">![[Aruspice.jpg]][[Aruspice.jpg|Voir]]</span>

<p class="traits">Lorem, Ipsum</p>

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```


## Objectifs

## Détails

## Relations

## Statistiques

## Secrets