
---
cssclass: 'npc'
tags: NPC Foghorn
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Alaric Foghorn
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [Relations](#Relations) [Statistiques](#Statistiques) [Secrets](#Secrets)</span>

```ad-desc
<span class="image">![[Alaric Foghorn.jpg]][[Alaric Foghorn.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>L'intendant de [[Brevoy]]</span>

<strong>Physique: </strong> 

<strong>Caractère: </strong>

```

## Objectifs
<span class="tab">[[Foghorn#Objectifs]]</span>
<span class="embed-section tab">![[Foghorn#Objectifs]]</span>

## Détails

## Relations

## Secrets

## Statistiques