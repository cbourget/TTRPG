
---

cssclass: 'npc'
tags: NPC Tamerlane

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Rackham

```ad-desc

<span class="image">![[Rackham.jpg]][[Rackham.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails
Un membre de la famille De-Beauvais qui s'est converti à la piraterie et qui travaille pour [[Tamerlane Foghorn]].
## Relations

## Secrets

## Statistiques