
---
cssclass: 'npc'
tags: NPC Carodoc Ligue-Frégate
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Randal Carodoc
```ad-desc

<span class="image">![[Randal Carodoc.jpg]][[Randal Carodoc.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Capitaine du [[Kelpie]].</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>

```


## Objectifs
<span class="tab">[[Carodoc#Objectifs]]</span>
<span class="embed-section tab">![[Carodoc#Objectifs]]</span>

## Détails

## Relations
<span class="tab">[[Carodoc#Relations]]</span>
<span class="embed-section tab">![[Carodoc#Relations]]</span>

## Secrets

## Statistiques