
---
cssclass: 'npc'
tags: NPC Non-Affilié
---
<span class="npc-tags">#Orc #Homme</span>

# Corgak
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [Relations](#Relations) [Statistiques](#Statistiques) [Secrets](#Secrets)</span>

```ad-desc

<span class="image">![[Corgak.jpg]][[Corgak.jpg|Voir]]</span>

<p class="traits">Lorem, Ipsum</p>

Un marin grognon qui appécie l'alcool.
```

## Objectifs
- [ ] S'enrichir
- [ ] Se refaire une vie ailleurs.

## Détails

## Relations

## Statistiques

## Secrets