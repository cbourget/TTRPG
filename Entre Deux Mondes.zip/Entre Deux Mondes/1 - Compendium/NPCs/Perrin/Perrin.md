
---
cssclass: 'npc'
tags: NPC Église-Osiron
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Perrin
```ad-desc
<span class="image">![[Perrin.jpg]][[Perrin.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
<span class="tab">[[Église d'Osiron#Objectifs]]</span>
<span class="embed-section tab">![[Église d'Osiron#Objectifs]]</span>

## Détails

## Relations
<span class="tab">[[Église d'Osiron#Relations]]</span>
<span class="embed-section tab">![[Église d'Osiron#Relations]]</span>

## Secrets

## Statistiques