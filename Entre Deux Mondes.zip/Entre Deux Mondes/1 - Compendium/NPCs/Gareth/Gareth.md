
---
cssclass: 'npc'
tags: NPC Non-Affilié
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Gareth
```ad-desc

<span class="image">![[Gareth.jpg]][[Gareth.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Ami de [[Ciel Phantomhive]].</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs
- [ ] Prouver son innocence et se refaire une vie ou bien intégrer les [[Capes Jaunes]].

## Détails

## Relations
| -                        | Relation                                                                                               |
| ------------------------ | ------------------------------------------------------------------------------------------------------ |
| [[Capes Jaunes]]         | En a peut car il est recherché par ces derniers mais aimerait intégrer leurs rangs.                                                                                            |
| [[Ciel Phantomhive]]                         | Ami                                                                                                       |

## Secrets

## Statistiques