
---

cssclass: 'npc'
tags: NPC Ilvastar Capes-Jaunes 

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails)  [Relations](#Relations) [Secrets](#Secrets) [Statistiques](#Statistiques)</span>

# Bran Ilvastar

```ad-desc

<span class="image">![[Bran Ilvastar.jpg]][[Bran Ilvastar.jpg|Voir]]</span>

<span class="npc-tags">#Humain #Homme</span>

<span>Lorem Ipsum</span>

<strong>Physique: </strong>

<strong>Caractère: </strong>
```

## Objectifs

## Détails

## Relations

## Secrets

## Statistiques