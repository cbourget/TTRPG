
---
tags: NPC
---

# Père Gawain
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

## Détails
### Voyage
## Secrets