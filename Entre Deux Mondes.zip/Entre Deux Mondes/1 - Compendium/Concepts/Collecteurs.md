
---
tags: Titre
---

# Collecteurs
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

À la mort, l’âme devient vagabonde et cherche un nouveau vaisseau. À cet instant, les Collecteurs, des adeptes spécialement formés, capturent l’[[Âme]] dans une fiole de sang et la transportent jusqu’à un temple d’[[Osiron]] pour qu’elle y soit consumée.

Les Collecteurs sont aussi à l’aise sur les champs de bataille que dans une messe car ce sont uniquement les âmes des infidèles qui sont consumées par l’[[Osiron#Oriflamme|Oriflamme]].

## Détails
## Secrets