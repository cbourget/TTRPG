
---
tags: Faction
---

# Ordre des Alchimistes
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

L'Ordre des Alchimistes est un groupe mis sur pied par [[Izalith Mantar]]. Ils vouent leur vie à cette pratique et tentent par le fait même d'accroître leur puissance 

## Détails
D’une part, à [[Latria]], les concoctions alchimiques ont complètement bouleversé le mode de vie et, pour cela, les alchimistes sont adulés et influents. D’autre part, les concoctions elles-mêmes permettent d’accroître les capacités et les alchimistes sont devenus très puissants graĉe à elles. Accrocs à ce pouvoir, ils désirent toujours en obtenir davantage et ils rêvent même de vivre éternellement. Leurs recherches et leurs motifs doivent cependant rester secrets. C’est de moins en moins évident avec la recrudescence des cas de dégénération. Pour cette raison, ils ont mis sur pied la [[Gulde des Chasseurs]], dont le but est d’éliminer ces dégénérés dans la plus grande discrétion.

## Secrets