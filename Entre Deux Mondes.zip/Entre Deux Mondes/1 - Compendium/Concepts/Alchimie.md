
---
---

# Alchimie
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

Dans sa plus simple expression, l'achimie agit sur la matière en la transformant. Cependant, en combinant l'[[Âme]] à la matière, il est possible d'obtenir des résultats beaucoup plus impressionnant.

## Détails
Toute comme les âmes peuvent être [[Âme#Contention d'âme#contenues]], elles peuvent aussi être jointes à des mixtures alchimiques. Ces mixtures devient alors très puissantes et permettent, entre autres, d'accroître les capacités physiques et mentales des récipiendaires.

Toutefois, les [[Âme|âmes]] ainsi ingérées ne sont pas liées à l'hôte et elles forment une sorte de symbiote à l'intérieur de ce dernier. Il peut devenir très difficile à contrôler et peut même finir par prendre le contrôle sur hôte. Les effusions de sang lors des combats ont tendance à exciter ses symbiotes et il devient difficile de ne pas succomber aux pulsions sadiques de ces symbiotes. Cette perte de contrôle est souvent nommé *dégénération* et les monstres qui en sont issus sont nommés *dégénérés*.

## Secrets