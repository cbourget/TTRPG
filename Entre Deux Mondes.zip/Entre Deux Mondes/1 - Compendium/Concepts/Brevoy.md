
---
tags: Lieu
---

# Brevoy
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

Un important royaume sur [[Boletaria]], berceau du nouveau clergé d'[[Osiron]].

## Détails
## Secrets