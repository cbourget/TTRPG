
---
---

# Donnyr Avian
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

Donnyr est un elfe qui était du groupe qui ont découvert les [[Pthumériens]]. Après [[Le Pacte]], il a choisi de se faire discret et a élu domicile dans la [[Forêt de Vernoir]].

## Détails
On raconte qu'il a incarné des [[Âme|âmes]] dans les arbes, les plantes, et les créatures de la forêt. Il aurait même incarné sa propre âme et aurait ainsi transcender la mort.

## Secrets