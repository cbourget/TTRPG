
---
tags: NPC
---

# Brome Firbor
<span class="nav">[Détails](#Détails) [Secrets](#Secrets)</span>

Brome est un bâtisseur qui était du groupe qui ont découvert les [[Pthumériens]]. Il a fondé la cité de [[Latria]] au-dessus du tombeau d'[[Osirion]] dans le but d'en faire une prison pour les [[Pthumériens]] dont le jugement est attendu au début de prochain millénaire. Il fût plus tard assisté par [[Izalith Mantar]] et l'[[Ordre des Alchimistes]]. Il n'a jamais maîtrisé la [[Âme#Contention d'âme|Contention d'âme]].

## Détails
## Secrets