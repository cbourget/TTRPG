```leaflet
id: brevoy-taverne
image: [[6 - Taverne.jpg]]
lat: 50
long: 50
height: 100%
minZoom: 7
maxZoom: 10
defaultZoom: 10
unit: meters
scale: 1
```