# Brevoy
```leaflet
id: brevoy
image: [[0 - Brevoy.jpg]]
lat: 50
long: 50
minZoom: 6
maxZoom: 10
defaultZoom: 6
unit: meters
scale: 1
```

## Localisations

[[1 - Port]]

[[2 - Rues]]

[[3 - Quartier de la Culture]]