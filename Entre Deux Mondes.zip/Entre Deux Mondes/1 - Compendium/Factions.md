---

cssclass: 'aggregate'

---

Factions
<span class="embed-note page-break">![[Capes Jaunes]]</span>
<span class="embed-note page-break">![[Carodoc]]</span>
<span class="embed-note page-break">![[Cragmire]]</span>
<span class="embed-note page-break">![[Église d'Osiron]]</span>
<span class="embed-note page-break">![[Estelmer]]</span>
<span class="embed-note page-break">![[Foghorn]]</span>
<span class="embed-note page-break">![[Guilde Marchande]]</span>
<span class="embed-note page-break">![Ilvastar]]</span>
<span class="embed-note page-break">![[Ligue Frégate]]</span>
<span class="embed-note page-break">![[Mantar]]</span>
<span class="embed-note page-break">![[Syndic Des Marchands]]</span>
<span class="embed-note page-break">![[Non-Affilié]]</span>
