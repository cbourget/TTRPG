---

cssclass: 'aggregate'

---

# Organisations
<span class="embed-note">[[Capes Jaunes]]</span>
<span class="embed-note">[[Carodoc]]</span>
<span class="embed-note">[[Cragmire]]</span>
<span class="embed-note">[[Église d'Osiron]]</span>
<span class="embed-note">[[Foghorn]]</span>
<span class="embed-note">[[Guilde Marchande]]</span>
<span class="embed-note">[[Ligue Frégate]]</span>
<span class="embed-note">[[Syndic Des Marchands]]</span>

# NPCs
<span class="embed-note">[[Agrippine]]</span>
<span class="embed-note">[[Alaric Foghorn]]</span>
<span class="embed-note">[[Aruspice]]</span>
<span class="embed-note">[[Cleyton Kilmer]]</span>
<span class="embed-note">[[Corbu]]</span>
<span class="embed-note">[[Frya Cragmire]]</span>
<span class="embed-note">[[Gareth]]</span>
<span class="embed-note">[[Grog]]</span>
<span class="embed-note">[[Hossulim]]</span>
<span class="embed-note">[[Jormun]]</span>
<span class="embed-note">[[Kretiak Cragmire]]</span>
<span class="embed-note">[[Nilheim]]</span>
<span class="embed-note">[[Perrin]]</span>
<span class="embed-note">[[Randal Carodoc]]</span>
<span class="embed-note">[[Ronzu]]</span>
<span class="embed-note">[[Roy Larg]]</span>
<span class="embed-note">[[Tamerlane Foghorn]]</span>
<span class="embed-note">[[Vonnder Cragmire]]</span>
<span class="embed-note">[[Wilhelm Oberon]]</span>
<span class="embed-note">[[Xendra Mantar]]</span>
