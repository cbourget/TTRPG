
---

cssclass: 'faction'
tags: Faction Fulgor

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Fulgor
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Opérer une forge au bénéfice de la colonie
- [ ] Trouver du fer et autres minerais rares (adamantium, mithril)

## Détails

## NPCs
```query
tag: NPC tag: Fulgor
```

## Relations

## Secrets
