
---

cssclass: 'faction'
tags: Faction Mantar

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Mantar
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Confirmer une théorie sur les portails magiques et le "plan transitoire"
- [ ] Découvrir, s'instruire et trouver des composantes magiques

## Détails

## NPCs
```query
tag: NPC tag: Mantar
```

## Relations

## Secrets
