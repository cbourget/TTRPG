
---

cssclass: 'faction'
tags: Faction Carodoc

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Carodoc
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
<span class="embed-section"> ![[Ligue Frégate#Objectifs]]</span>

## Détails

## NPCs
```query
tag: NPC tag: Carodoc
```

## Relations

## Secrets