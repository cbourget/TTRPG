
---

cssclass: 'faction'
tags: Faction Académie-des-Noms

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Académie des Noms
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ]  Investiguer sur [[Wanageeska]]
- [ ] Compiler les données sur la colonie et sa croissance

## Détails

## NPCs
```query
tag: NPC tag: Académie-des-Noms
```

## Relations

## Secrets
