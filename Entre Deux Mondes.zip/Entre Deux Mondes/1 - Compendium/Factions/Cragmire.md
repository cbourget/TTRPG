
---
cssclass: 'faction'
tags: Faction Cragmire
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Cragmire
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Trouver le cor des dragons qui permet de les commander.
- [ ] Trouver des dragons.
- [ ] Trouver un portail permettant de faire traverser les dragons sur le continent.

## Détails

## NPCs
```query
tag: NPC tag: Cragmire
```

## Relations

## Secrets