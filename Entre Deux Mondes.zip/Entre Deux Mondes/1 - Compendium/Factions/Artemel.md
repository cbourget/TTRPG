
---

cssclass: 'faction'
tags: Faction Artemel

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Artemel
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Découvrir et apprivoiser de nouvelles créatures dont le légendaire cheval à 6 pattes.

## Détails

## NPCs
```query
tag: NPC tag: Artemel
```

## Relations

## Secrets
