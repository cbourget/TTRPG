
---
cssclass: 'faction'
tags: Faction Pictis
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Pictis
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs

## Détails

## NPCs
```query
tag: NPC tag: Pictis
```

## Relations

## Secrets