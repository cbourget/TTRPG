
---
cssclass: 'faction'
tags: Faction Foghorn
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Foghorn
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Fonder une colonie et trouver des ressources pour la mère patrie (fer, nourriture)
- [ ] Garder un oeil les rivaux d'[[Alaric Foghorn|Alaric]] qui voudront prendre sa place une fois la guerre achevée.

## Détails

## NPCs
```query
tag: NPC tag: Foghorn
```

## Relations

## Secrets