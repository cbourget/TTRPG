
---
cssclass: 'faction'
tags: Faction Syndic-Des-Marchands
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Syndic Des Marchands
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Trouver des opportunités de commerce et établir un comptoir.

## Détails

## NPCs
```query
tag: NPC tag: Syndic-Des-Marchands
```

## Relations

## Secrets