
---

cssclass: 'faction'
tags: Faction Lanngolyn

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Lanngolyn
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Trouver des opportunités d'affaire et/ou découvrir de nouvelles plantes (café ?)

## Détails

## NPCs
```query
tag: NPC tag: Lanngolyn
```

## Relations

## Secrets
