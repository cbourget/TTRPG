
---

cssclass: 'faction'
tags: Faction Ilvastar

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Ilvastar
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Trouver un remède à l'affliction. Ils ont capturé un collaborateur des Duriens et ont une piste au sujet du [[Mangifer]].

## Détails

## NPCs
```query
tag: NPC tag: Ilvastar
```

## Relations

## Secrets
