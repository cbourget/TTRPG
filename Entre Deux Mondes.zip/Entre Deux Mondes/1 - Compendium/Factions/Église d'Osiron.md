
---

cssclass: 'faction'
tags: Faction Église-Osiron

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Église d'Osiron
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Rehausser la foi à [[Brevoy]] en trouvant une sainte relique
- [ ] Convertir des indigènes
- [ ] Se positionner pour accéder au pouvoir en rehaussant leur prestige
- [ ] Trouver un remède à l'affliction des mages.

## Détails

## NPCs
```query
tag: NPC tag: Église-Osiron
```

## Relations

## Secrets