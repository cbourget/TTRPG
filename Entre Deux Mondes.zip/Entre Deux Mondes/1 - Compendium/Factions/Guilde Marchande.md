
---
cssclass: 'faction'
tags: Faction Guilde-Marchande
---
<span class="nav"> [Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Guilde Marchande
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Trouver des opportunités de commerce et établir un comptoir.

## Détails

## NPCs
```query
tag: NPC tag: Guilde-Marchande
```


## Relations

## Secrets