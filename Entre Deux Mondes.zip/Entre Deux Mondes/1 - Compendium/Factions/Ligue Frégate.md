
---

cssclass: 'faction'
tags: Faction Ligue-Frégate

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Ligue Frégate
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] S'auver la ligue de la faillite et redorer son image
- [ ] Établir une voie maritime vers [[Nostaria]]

## Détails

## NPCs
```query
tag: NPC tag: Ligue-Frégate
```

## Relations

## Secrets