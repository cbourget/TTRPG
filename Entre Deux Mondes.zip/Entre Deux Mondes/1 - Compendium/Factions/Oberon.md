
---

cssclass: 'faction'
tags: Faction Oberon

---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [NPCs](#NPCs) [Relations](#Relations) [Secrets](#Secrets)</span>

# Oberon
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs
- [ ] Avoir un pied à terre à [[Nostaria]]
- [ ] Régler certains comptes à l'appri de la justice de [[Brevoy]]

## Détails

## NPCs
```query
tag: NPC tag: Oberon
```

## Relations

## Secrets
