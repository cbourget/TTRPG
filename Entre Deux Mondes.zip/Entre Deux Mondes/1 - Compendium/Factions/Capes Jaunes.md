
---
cssclass: 'faction'
tags: Faction Capes-Jaunes
---
<span class="nav">[Objectifs](#Objectifs) [Détails](#Détails) [Relations](#Relations) [Secrets](#Secrets)</span>

# Capes Jaunes
```ad-desc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```

## Objectifs

## Détails

## NPCs
```query
tag: NPC tag: Capes-Jaunes
```

## Relations

## Secrets