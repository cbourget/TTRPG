---

cssclass: 'aggregate'

---

# Organisations
<span class="embed-note page-break">![[Capes Jaunes]]</span>
<span class="embed-note page-break">![[Carodoc]]</span>
<span class="embed-note page-break">![[Cragmire]]</span>
<span class="embed-note page-break">![[Église d'Osiron]]</span>
<span class="embed-note page-break">![[Foghorn]]</span>
<span class="embed-note page-break">![[Guilde Marchande]]</span>
<span class="embed-note page-break">![[Ligue Frégate]]</span>
<span class="embed-note page-break">![[Syndic Des Marchands]]</span>

# NPCs
<span class="embed-note page-break">![[Agrippine]]</span>
<span class="embed-note page-break">![[Alaric Foghorn]]</span>
<span class="embed-note page-break">![[Aruspice]]</span>
<span class="embed-note page-break">![[Cleyton Kilmer]]</span>
<span class="embed-note page-break">![[Corbu]]</span>
<span class="embed-note page-break">![[Frya Cragmire]]</span>
<span class="embed-note page-break">![[Gareth]]</span>
<span class="embed-note page-break">![[Grog]]</span>
<span class="embed-note page-break">![[Hossulim]]</span>
<span class="embed-note page-break">![[Jormun]]</span>
<span class="embed-note page-break">![[Kretiak Cragmire]]</span>
<span class="embed-note page-break">![[Nilheim]]</span>
<span class="embed-note page-break">![[Perrin]]</span>
<span class="embed-note page-break">![[Randal Carodoc]]</span>
<span class="embed-note page-break">![[Ronzu]]</span>
<span class="embed-note page-break">![[Roy Larg]]</span>
<span class="embed-note page-break">![[Tamerlane Foghorn]]</span>
<span class="embed-note page-break">![[Vonnder Cragmire]]</span>
<span class="embed-note page-break">![[Wilhelm Oberon]]</span>
<span class="embed-note page-break">![[Xendra Mantar]]</span>
